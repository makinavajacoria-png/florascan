"""
FloraScan — Backend v4.11 (estabilización y medición de tiempos)
- Gemini (principal) + Qwen (respaldo) + modelo local (último recurso).
- Pl@ntNet priorizado para identificación.
- Logs mejorados para depurar fallos.
Ejecutar:
    python main.py
"""

import base64
import io
import json
import os
import re
import time
from pathlib import Path

import numpy as np
import requests
from dotenv import load_dotenv
from fastapi import FastAPI, File, Header, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from PIL import Image, ImageOps


def _post_medido(etiqueta, *args, **kwargs):
    """Ejecuta requests.post y registra el tiempo real de cada intento HTTP."""
    inicio = time.perf_counter()
    try:
        respuesta = requests.post(*args, **kwargs)
        segundos = time.perf_counter() - inicio
        print(f"⏱️ [HTTP {etiqueta}] HTTP {respuesta.status_code} en {segundos:.2f} s")
        return respuesta
    except Exception as exc:
        segundos = time.perf_counter() - inicio
        print(f"⏱️ [HTTP {etiqueta}] {type(exc).__name__} tras {segundos:.2f} s")
        raise


try:
    from pillow_heif import register_heif_opener
    register_heif_opener()
    print("✅ Soporte HEIC activado")
except Exception:
    pass


# ============================================================
# CONFIG
# ============================================================

load_dotenv()

BASE = Path(__file__).parent
MODELO_DIR = BASE / "modelo"

PLANTNET_KEY = os.getenv("PLANTNET_API_KEY", "").strip()
GEMINI_KEY = os.getenv("GEMINI_API_KEY", "").strip()
QWEN_KEY = os.getenv("QWEN_API_KEY", "").strip()
QWEN_BASE = os.getenv("QWEN_BASE_URL", "https://dashscope-intl.aliyuncs.com/compatible-mode/v1").rstrip("/")
QWEN_MODELOS = [m.strip() for m in os.getenv("QWEN_MODELOS", "qwen/qwen2.5-vl-72b-instruct").split(",") if m.strip()]

# ============================================================
# EJECUTOR GLOBAL DE HILOS (Optimización de CPU en Render)
# ============================================================
from concurrent.futures import ThreadPoolExecutor
from threading import Lock

EXECUTOR = ThreadPoolExecutor(max_workers=4)

MAX_IMAGE_BYTES = int(os.getenv("MAX_IMAGE_BYTES", str(10 * 1024 * 1024)))  # 10 MB
STATS_TOKEN = os.getenv("STATS_TOKEN", "").strip()

app = FastAPI(title="FloraScan API", version="4.11")


@app.middleware("http")
async def medir_tiempo_peticion(request, call_next):
    """Mide duración total de cada petición HTTP, especialmente /analizar."""
    inicio = time.perf_counter()
    try:
        return await call_next(request)
    finally:
        segundos = time.perf_counter() - inicio
        if request.url.path == "/analizar":
            print(f"⏱️ [FloraScan TOTAL] {request.method} {request.url.path} en {segundos:.2f} s")
        elif request.url.path not in ("/", "/favicon.ico"):
            print(f"⏱️ [HTTP TOTAL] {request.method} {request.url.path} en {segundos:.2f} s")

# La interfaz se sirve desde el mismo backend. Si se necesita CORS externo,
# definir CORS_ALLOWED_ORIGINS como una lista separada por comas.
CORS_ALLOWED_ORIGINS = [x.strip() for x in os.getenv("CORS_ALLOWED_ORIGINS", "").split(",") if x.strip()]
if CORS_ALLOWED_ORIGINS:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=CORS_ALLOWED_ORIGINS,
        allow_methods=["GET", "POST", "OPTIONS"],
        allow_headers=["Content-Type", "Authorization", "X-Stats-Token"],
    )


# ============================================================
# CONOCIMIENTO: NOMBRES COMUNES
# ============================================================

NOMBRES_COMUNES = {
    "plectranthus verticillatus": "Planta del dinero",
    "epipremnum aureum": "Potos / Pothos",
    "monstera deliciosa": "Monstera",
    "monstera adansonii": "Monstera adansonii",
    "rhaphidophora tetrasperma": "Mini monstera",
    "ficus benjamina": "Ficus benjamina",
    "ficus lyrata": "Higuera hoja de violín",
    "dracaena trifasciata": "Lengua de suegra",
    "sansevieria trifasciata": "Lengua de suegra",
    "spathiphyllum wallisii": "Espatifilo / Cuna de Moisés",
    "aloe vera": "Aloe vera",
    "lavandula angustifolia": "Lavanda",
    "lavandula": "Lavanda",
    "olea europaea": "Olivo",
    "vitis vinifera": "Vid",
    "citrus sinensis": "Naranjo dulce",
    "citrus limon": "Limonero",
    "citrus × aurantium": "Naranjo amargo",
    "citrus aurantium": "Naranjo amargo",
    "prunus dulcis": "Almendro",
    "nerium oleander": "Adelfa",
    "solanum lycopersicum": "Tomate",
    "solanum tuberosum": "Patata",
    "fragaria": "Fresa",
    "persea americana": "Aguacate",
    "coffea arabica": "Cafeto",
    "musa": "Platanera",
    "rosa": "Rosal",
    "trachelospermum jasminoides": "Falso jazmín / Jazmín estrella",
    "jasminum": "Jazmín",
    "chassalia corallioides": "Arbusto coral",
    "quercus suber": "Alcornoque",
    "quercus ilex": "Encina",
    "quercus robur": "Roble",
    "pinus": "Pino",
    "arbutus unedo": "Madroño",
    "laurus nobilis": "Laurel",
}


def normalizar_nombre_cientifico(nombre):
    if not nombre:
        return ""
    n = nombre.lower().strip().split(" (")[0].strip()
    partes = n.split()
    if len(partes) >= 3 and partes[1] == "×":
        return " ".join(partes[:3])
    if len(partes) >= 2:
        return " ".join(partes[:2])
    return n


def nombre_comun_es(cientifico):
    if not cientifico:
        return None
    base = normalizar_nombre_cientifico(cientifico)
    if base in NOMBRES_COMUNES:
        return NOMBRES_COMUNES[base]
    genero = base.split()[0] if base else ""
    return NOMBRES_COMUNES.get(genero)


# ============================================================
# CONOCIMIENTO: CULTIVOS
# ============================================================

CULTIVOS = {
    "solanum lycopersicum": "tomate", "solanum tuberosum": "patata",
    "malus": "manzano", "vitis": "vid", "fragaria": "fresa", "citrus": "citricos",
}

PREFIJO_CULTIVO = {
    "Tomato": "tomate", "Potato": "patata", "Apple": "manzano",
    "Grape": "vid", "Strawberry": "fresa", "Orange": "citricos",
}

CLASE_LOCAL_A_CULTIVO = {
    "tomate": "tomate", "vid": "vid", "fresa": "fresa",
    "naranjo": "citricos", "limonero": "citricos",
}


# ============================================================
# CONOCIMIENTO: FICHAS DE CUIDADO
# ============================================================

PERFILES_CUIDADO = [
    {
        "claves": ("lavandula", "lavanda", "rosmarinus", "romero", "thymus", "tomillo", "salvia"),
        "grupo": "Aromática mediterránea",
        "riego": "Escaso: deja secar el sustrato entre riegos",
        "luz": "Pleno sol",
        "tipico": "Exceso de riego y humedad en raíces",
        "consejo_sintomas": "En aromáticas mediterráneas, muchas manchas o decaimiento vienen de exceso de riego o mal drenaje.",
    },
    {
        "claves": (
            "monstera", "epipremnum", "pothos", "potos", "philodendron",
            "spathiphyllum", "espatifilo", "ficus", "syngonium",
            "chlorophytum", "cinta", "plectranthus",
        ),
        "grupo": "Tropical de interior",
        "riego": "Moderado: riega cuando los primeros 2-3 cm del sustrato estén secos",
        "luz": "Luz brillante indirecta",
        "tipico": "Puntas marrones por aire seco, riego irregular o exceso de agua",
        "consejo_sintomas": "En tropicales, revisa riego, humedad ambiental, corrientes de aire y limpia el polvo de las hojas.",
    },
    {
        "claves": ("trachelospermum", "jasminoides", "jasminum", "jazmin", "jazmín"),
        "grupo": "Jazmín / enredadera ornamental",
        "riego": "Moderado, evitando encharcar",
        "luz": "Sol suave o semisombra luminosa",
        "tipico": "Hongos foliares, cochinilla, araña roja y estrés por riego",
        "consejo_sintomas": "En jazmines, las manchas suelen relacionarse con hongos o estrés. Retira hojas afectadas.",
    },
    {
        "claves": (
            "sansevieria", "trifasciata", "dracaena trifasciata",
            "lengua de suegra", "aloe", "crassula", "echeveria",
            "sedum", "opuntia", "cact", "zamioculcas",
        ),
        "grupo": "Suculenta / cactácea",
        "riego": "Muy escaso: solo cuando el sustrato esté totalmente seco",
        "luz": "Mucha luz, incluso sol directo progresivo",
        "tipico": "Pudrición por exceso de riego",
        "consejo_sintomas": "En suculentas, hojas blandas o translúcidas suelen indicar exceso de agua.",
    },
    {
        "claves": ("citrus", "naranjo", "limonero", "aurantium", "sinensis", "limon"),
        "grupo": "Cítrico",
        "riego": "Regular sin encharcar",
        "luz": "Pleno sol",
        "tipico": "Clorosis férrica, cochinilla, minador y hongos foliares",
        "consejo_sintomas": "En cítricos, el amarilleo suele ser carencia o riego irregular.",
    },
    {
        "claves": ("olea", "olivo"),
        "grupo": "Olivo", "riego": "Escaso una vez establecido", "luz": "Pleno sol",
        "tipico": "Repilo y problemas por humedad excesiva",
        "consejo_sintomas": "En olivo, manchas circulares o plateadas pueden ser repilo.",
    },
    {
        "claves": ("vitis", "vid"),
        "grupo": "Vid", "riego": "Escaso; sensible al encharcamiento", "luz": "Pleno sol",
        "tipico": "Mildiu, oídio y botritis",
        "consejo_sintomas": "En vid, revisa el envés: mildiu suele dar vellosidad blanca.",
    },
    {
        "claves": ("rosa", "rosal"),
        "grupo": "Rosal", "riego": "Regular al pie, sin mojar hojas",
        "luz": "Pleno sol con buena ventilación",
        "tipico": "Mancha negra, oídio, roya y pulgón",
        "consejo_sintomas": "En rosales, manchas negras y amarilleo suelen indicar mancha negra.",
    },
    {
        "claves": ("quercus", "alcornoque", "encina", "roble", "castanea", "castaño", "fagus", "haya"),
        "grupo": "Fagácea / árbol mediterráneo",
        "riego": "Normalmente no necesita riego una vez establecido",
        "luz": "Pleno sol o semisombra",
        "tipico": "Estrés hídrico, suelo compactado, hongos de raíz",
        "consejo_sintomas": "En quercus, vigila sequía prolongada o encharcamiento.",
    },
    {
        "claves": ("pinus", "pino", "abies", "abeto", "cedrus", "cedro", "picea"),
        "grupo": "Conífera", "riego": "Escaso una vez establecida", "luz": "Pleno sol",
        "tipico": "Procesionaria, hongos y estrés por sequía",
        "consejo_sintomas": "En coníferas, revisa acículas marrones o bolsones blancos.",
    },
    {
        "claves": ("arbutus", "madroño", "erica", "brezo", "calluna", "azalea", "rhododendron"),
        "grupo": "Acidófila / ericácea",
        "riego": "Moderado, con suelo ácido y drenante", "luz": "Semisombra a sol suave",
        "tipico": "Clorosis por agua o suelo calizo",
        "consejo_sintomas": "En acidófilas, hojas amarillas con nervios verdes suelen indicar pH alto.",
    },
    {
        "claves": ("laurus", "laurel", "persea", "aguacate"),
        "grupo": "Laurácea", "riego": "Moderado sin encharcar", "luz": "Sol suave o luz brillante",
        "tipico": "Pudrición de raíz por exceso de agua",
        "consejo_sintomas": "En lauráceas, hojas mustias con sustrato húmedo pueden indicar raíces dañadas.",
    },
    {
        "claves": ("prunus", "almendro", "cerezo", "ciruelo", "melocotonero", "durazno"),
        "grupo": "Rosácea / frutal de hueso",
        "riego": "Moderado, sin encharcar", "luz": "Pleno sol",
        "tipico": "Cribado, monilia, pulgón y hongos foliares",
        "consejo_sintomas": "En prunus, agujeros o manchas rojizas pueden ser cribado.",
    },
    {
        "claves": ("nerium", "adelfa"),
        "grupo": "Apocinácea / arbusto ornamental",
        "riego": "Moderado, tolera sequía una vez establecida",
        "luz": "Pleno sol",
        "tipico": "Cochinilla, pulgón y hongos foliares",
        "consejo_sintomas": "En adelfas, revisa el envés por cochinilla y evita mojar las hojas al regar.",
    },
]


def perfil_de(textos):
    for t in textos:
        if not t: continue
        tx = t.lower()
        for p in PERFILES_CUIDADO:
            if any(k in tx for k in p["claves"]):
                return p
    return None


# ============================================================
# CARGA DE MODELOS ONNX
# ============================================================

def cargar_onnx(nombre):
    try:
        import onnxruntime as ort
        sesion = ort.InferenceSession(str(MODELO_DIR / nombre))
        print(f"✅ Cargado {nombre}")
        return sesion
    except Exception as e:
        print(f"⚠️ No se cargó {nombre} ({type(e).__name__}: {e})")
        return None


SESION_LOCAL = cargar_onnx("modelo_florascan.onnx")
SESION_SALUD = cargar_onnx("modelo_salud.onnx")
SESION_ANOMALIA = cargar_onnx("modelo_anomalia_v2.onnx")

MAPEO_LOCAL = {}
try:
    m = json.loads((MODELO_DIR / "mapeo_clases.json").read_text(encoding="utf-8"))
    MAPEO_LOCAL = {v: k for k, v in m.items()}
    print("✅ Cargado mapeo_clases.json")
except Exception as e:
    print(f"⚠️ No se cargó mapeo_clases.json: {e}")

MAPEO_SALUD = {}
try:
    MAPEO_SALUD = json.loads((MODELO_DIR / "mapeo_salud.json").read_text(encoding="utf-8"))
    print("✅ Cargado mapeo_salud.json")
except Exception as e:
    print(f"⚠️ No se cargó mapeo_salud.json: {e}")


def preproceso_onnx(img):
    arr = np.asarray(img.convert("RGB").resize((224, 224)), dtype=np.float32) / 255.0
    return np.expand_dims(arr, axis=0)


def correr(sesion, img):
    if sesion is None: return None
    entrada = sesion.get_inputs()[0].name
    return sesion.run(None, {entrada: preproceso_onnx(img)})[0][0]


def identificar_local(img, top_k=3):
    probs = correr(SESION_LOCAL, img)
    if probs is None: return []
    idx = np.argsort(probs)[::-1][:top_k]
    return [{"clase": MAPEO_LOCAL.get(int(i), "?"), "confianza": round(float(probs[i]), 3)} for i in idx]


# ============================================================
# PL@NTNET
# ============================================================

def identificar_plantnet(img_bytes):
    if not PLANTNET_KEY:
        print("⚠️ PLANTNET_API_KEY no configurada")
        return []
    try:
        r = _post_medido("Pl@ntNet identificación",
            "https://my-api.plantnet.org/v2/identify/all",
            params={"api-key": PLANTNET_KEY, "lang": "es"},
            files={"images": ("foto.jpg", img_bytes, "image/jpeg")},
            timeout=8,  # ← CAMBIAR AQUÍ (estaba en 30)
        )
        r.raise_for_status()
        out = []
        for res in r.json().get("results", [])[:3]:
            sp = res.get("species", {}) or {}
            sci = (sp.get("scientificName") or "").strip() or None
            comun = (sp.get("commonName") or nombre_comun_es(sci) or "").strip() or None
            # No aceptar resultados sin nombre de especie, aunque tengan score.
            if not sci and not comun:
                continue
            out.append({
                "nombre_cientifico": sci,
                "nombre_comun": comun,
                "confianza": round(float(res.get("score", 0)), 3),
            })
        print(f"🌿 Pl@ntNet: {out[0]['nombre_comun'] if out else 'sin resultados'} ({out[0]['confianza'] if out else 0})")
        return out
    except Exception as e:
        print(f"⚠️ Pl@ntNet: {e}")
        return []


def elegir_especie(plantnet, local):
    """
    Prioriza Pl@ntNet si tiene confianza >= 0.40.
    Si no, usa modelo local solo si tiene confianza >= 0.60.
    """
    textos = []
    
    # Pl@ntNet con alta confianza manda
    if plantnet and plantnet[0].get("confianza", 0) >= 0.40:
        textos.append(plantnet[0].get("nombre_cientifico"))
        textos.append(plantnet[0].get("nombre_comun"))
        print(f"✅ Especie elegida: Pl@ntNet ({plantnet[0]['nombre_comun']})")
        return "plantnet", textos
    
    # Modelo local solo si tiene alta confianza
    if local and local[0].get("confianza", 0) >= 0.60:
        textos.append(local[0].get("clase"))
        print(f"✅ Especie elegida: Local ({local[0]['clase']})")
        return "local", textos
    
    # Si no hay confianza suficiente, no presentar una especie como segura.
    if plantnet and (plantnet[0].get("nombre_cientifico") or plantnet[0].get("nombre_comun")):
        textos.extend(x for x in (plantnet[0].get("nombre_cientifico"), plantnet[0].get("nombre_comun")) if x)
        print(f"⚠️ Especie candidata de Pl@ntNet con baja confianza: {plantnet[0].get('nombre_comun') or plantnet[0].get('nombre_cientifico')}")
        return "plantnet_baja_confianza", textos
    
    # No usar la predicción local de baja confianza como identificación definitiva.
    if local:
        print(f"⚠️ Modelo local sin confianza suficiente ({local[0].get('clase')})")
    
    print("⚠️ No se pudo identificar especie")
    return "ninguna", textos


def detectar_cultivo(plantnet, local):
    if plantnet:
        sci = (plantnet[0].get("nombre_cientifico") or "").lower()
        for clave, cultivo in CULTIVOS.items():
            if clave in sci: return cultivo
    if local:
        return CLASE_LOCAL_A_CULTIVO.get(local[0].get("clase"))
    return None


# ============================================================
# UTILIDADES COMPARTIDAS
# ============================================================

def imagen_a_jpeg_bytes(img, max_px=1280):
    im = img.convert("RGB")
    w, h = im.size
    escala = min(1.0, max_px / max(w, h))
    if escala < 1.0:
        im = im.resize((int(w * escala), int(h * escala)))
    bio = io.BytesIO()
    im.save(bio, format="JPEG", quality=88)
    return bio.getvalue()


def extraer_json(texto):
    texto = texto.strip().replace("```json", "").replace("```", "").strip()
    try:
        return json.loads(texto)
    except Exception:
        pass
    match = re.search(r"\{.*\}", texto, re.DOTALL)
    base = match.group(0) if match else texto
    sufijos = ["", "}", "]}", "\"}", "\"]}", "\"}]}", "]}}", "\"]}}", "\",\"tratamiento\":[],\"prevencion\":[]}"]
    for suf in sufijos:
        try:
            return json.loads(base + suf)
        except Exception:
            continue
    raise ValueError("No se encontró JSON válido en la respuesta")


def normalizar_estado(estado):
    e = (estado or "").lower().strip()
    if e in ("saludable", "sano", "sana", "ok"): return "saludable"
    if e in ("critico", "crítico", "grave", "severo"): return "critico"
    if e in ("atencion", "atención", "moderado", "leve", "enfermo", "enferma"): return "atencion"
    return "atencion"

MODO_PRUEBA_QWEN = False   # ⚠️ Ponla en False cuando termines de probar


PROMPT_DIAGNOSTICO = """Actúa como fitopatólogo experto pero escribe como un divulgador: lenguaje cotidiano que entienda cualquier persona sin conocimientos de jardinería
- Evita palabras técnicas; si una es imprescindible, explícala entre paréntesis con palabras simples (ejemplo: "sustrato (la tierra de la maceta)", "acaricida (producto contra las arañas rojas)", "necrosis (tejido muerto y seco)")
- Frases cortas, claras y cercanas, como se lo explicarías a un amigo: di qué hacer, con qué y cada cuánto.{contexto}

Devuelve exactamente:
{{
  "especie": "nombre común o 'no identificada'",
  "estado": "saludable" | "atencion" | "critico",
  "confianza": 0.0,
  "patogeno": "plaga o patógeno detectado o null",
  "sintomas": ["máximo 3 síntomas visibles"],
  "diagnostico": "qué le pasa en 1 frase",
  "tratamiento": ["máximo 3 pasos concretos"],
  "prevencion": ["1 medida preventiva"],
  "luz": "necesidad de luz de la especie en 3-6 palabras",
  "riego": "frecuencia de riego de la especie en 3-8 palabras",
  "guia": {{
    "diagnostico_detallado": "párrafo de 3-4 frases: qué le pasa, causa probable, gravedad",
    "aislamiento": "instrucciones de aislamiento respecto a otras plantas",
    "pasos": ["5 a 7 pasos concretos y accionables para curar la planta, en orden"],
    "productos": ["productos o remedios caseros con dosis y frecuencia de aplicación"],
    "riego": "cómo ajustar el riego durante la recuperación",
    "luz_sustrato": "ajustes de luz, sustrato y abonado durante la recuperación",
    "plazo": "semanas estimadas de recuperación y señales de mejoría a vigilar",
    "prevencion": "cómo evitar que el problema reaparezca"
  }}
}}

Reglas:
- Si NO ves síntomas: estado="saludable", sintomas=[], tratamiento=[], guia limitada a rutina de cuidados y prevención en 3 líneas
- Si ves manchas, amarilleo, polvo blanco o necrosis: NO digas saludable, desarrolla la guía completa de recuperación
- Usa "posible / compatible con" si no hay certeza
- "luz" y "riego" SIEMPRE rellenos según la especie identificada
- Actúa como fitopatólogo y jardinero experto: la guía debe ser un plan de recuperación real, paso a paso, en español, con cantidades, frecuencias y productos concretos
- Español, conciso, sin markdown"""


def construir_resultado(resultado, especie_contexto, modelo_nombre):
    estado = normalizar_estado(resultado.get("estado"))
    sintomas = resultado.get("sintomas") or []
    tratamiento = resultado.get("tratamiento") or []
    prevencion = resultado.get("prevencion") or []
    if not isinstance(sintomas, list): sintomas = [str(sintomas)]
    if not isinstance(tratamiento, list): tratamiento = [str(tratamiento)]
    if not isinstance(prevencion, list): prevencion = [str(prevencion)]
    try:
        confianza = max(0.0, min(1.0, float(resultado.get("confianza", 0.7))))
    except Exception:
        confianza = 0.7
    return {
        "especie": resultado.get("especie") or especie_contexto or "no identificada",
        "estado": estado, "confianza": confianza,
        "patogeno": resultado.get("patogeno") or "",
        "sintomas": sintomas,
        "diagnostico": resultado.get("diagnostico") or "",
        "tratamiento": tratamiento, "prevencion": prevencion,
        "guia": resultado.get("guia") or {},
        "modelo": modelo_nombre,
    }


def texto_libre_como_respaldo(texto, especie_contexto, modelo_nombre):
    """Si no hay JSON, usa el texto crudo como diagnóstico."""
    if not texto or len(texto) < 30:
        return None
    if texto.lstrip().startswith("{"):
        return None
    return {
        "especie": especie_contexto or "no identificada",
        "estado": "atencion", "confianza": 0.5,
        "patogeno": "",
        "sintomas": [],
        "diagnostico": texto,
        "tratamiento": [], "prevencion": [],
        "guia": {},
        "modelo": modelo_nombre,
    }


# ============================================================
# GEMINI (principal)
# ============================================================

MODELOS_GEMINI = ["gemini-3.8-flash", "gemini-3.6-flash", "gemini-3.5-flash"]


def _texto_de_respuesta_gemini(r):
    data = r.json()
    parts = data["candidates"][0]["content"]["parts"]
    return "".join(p.get("text", "") for p in parts).strip()


def _registrar_uso_gemini(r, modelo, tipo):
    """Registra tokens de entrada/salida devueltos por la API, sin otra llamada."""
    try:
        data = r.json()
        uso = data.get("usageMetadata") or data.get("usage_metadata") or {}
        entrada = uso.get("promptTokenCount", uso.get("prompt_token_count"))
        salida = uso.get("candidatesTokenCount", uso.get("candidates_token_count"))
        pensamiento = uso.get("thoughtsTokenCount", uso.get("thoughts_token_count", 0)) or 0
        total = uso.get("totalTokenCount", uso.get("total_token_count"))
        if entrada is None and salida is None:
            print(f"💰 [TOKENS {tipo}] modelo={modelo}: la respuesta no incluye usageMetadata")
            return

        # Precios estándar de la API, USD por millón de tokens. Para Gemini 3.8/3.6
        # se aplica el precio introductorio vigente hasta el 31-12-2026.
        # Los tokens de pensamiento se suman a la salida facturable.
        if modelo in ("gemini-3.8-flash", "gemini-3.6-flash"):
            precio_entrada, precio_salida = 0.75, 3.75
        elif modelo == "gemini-3.5-flash":
            precio_entrada, precio_salida = 1.50, 9.00
        else:
            precio_entrada = precio_salida = None

        coste = None
        if precio_entrada is not None:
            coste = ((entrada or 0) * precio_entrada + ((salida or 0) + pensamiento) * precio_salida) / 1_000_000

        linea = (
            f"💰 [TOKENS {tipo}] modelo={modelo} | entrada={entrada or 0} | "
            f"salida={salida or 0} | pensamiento={pensamiento} | "
            f"total={total if total is not None else (entrada or 0) + (salida or 0) + pensamiento}"
        )
        if coste is not None:
            linea += f" | coste_estimado=${coste:.8f} USD (tarifa API de pago, sin descuentos)"
        else:
            linea += " | coste_estimado=no configurado para este modelo"
        print(linea)
    except Exception as exc:
        print(f"⚠️ No se pudieron leer tokens de Gemini ({tipo}, {modelo}): {type(exc).__name__}")


def _pedir_texto_gemini(modelo, prompt, img_b64, forzar_json, tipo="Gemini"):

    url = f"https://generativelanguage.googleapis.com/v1beta/models/{modelo}:generateContent"
    partes = [
        {"text": prompt},
        {"inline_data": {"mime_type": "image/jpeg", "data": img_b64}},
    ]
    cfg = {"temperature": 0.2, "topP": 0.8, "maxOutputTokens": 4096}
    if forzar_json:
        cfg["response_mime_type"] = "application/json"
    try:
        r = _post_medido(f"Gemini {modelo} intento 1",
            url, params={"key": GEMINI_KEY},
            json={"contents": [{"parts": partes}], "generationConfig": cfg},
            timeout=20,
        )
        if r.status_code == 404:
            print(f"⚠️ Gemini modelo no disponible: {modelo}")
            return "no_modelo"
        if r.status_code in (429, 503):
            print(f"⚠️ Gemini ({modelo}): {r.status_code} — reintentando en 2 s")
            time.sleep(2)
            r = _post_medido(f"Gemini {modelo} reintento",
                url, params={"key": GEMINI_KEY},
                json={"contents": [{"parts": partes}], "generationConfig": cfg},
                timeout=20,
            )
        r.raise_for_status()
        _registrar_uso_gemini(r, modelo, tipo)
        return _texto_de_respuesta_gemini(r)
    except requests.HTTPError as e:
        code = getattr(getattr(e, "response", None), "status_code", None)
        print(f"⚠️ Gemini ({modelo}): HTTP {code}")
        return None
    except Exception as e:
        print(f"⚠️ Gemini ({modelo}): {type(e).__name__}: {e}")
        return None


def diagnostico_gemini(img, especie_contexto=None):
    if not GEMINI_KEY:
        print("⚠️ GEMINI_API_KEY no configurada")
        return None
    contexto = f"\nIdentificación botánica probable: {especie_contexto}." if especie_contexto else ""
    prompt = PROMPT_DIAGNOSTICO.format(contexto=contexto)
    img_bytes = imagen_a_jpeg_bytes(img)
    img_b64 = base64.b64encode(img_bytes).decode("utf-8")

    for modelo in MODELOS_GEMINI:
        texto = _pedir_texto_gemini(modelo, prompt, img_b64, forzar_json=True, tipo="DIAGNOSTICO")
        if texto == "no_modelo" or texto is None:
            continue
        resultado = None
        try:
            resultado = extraer_json(texto)
        except ValueError:
            print(f"⚠️ Gemini ({modelo}): JSON inválido. Texto: {texto[:150]!r}")
            texto2 = _pedir_texto_gemini(modelo, prompt, img_b64, forzar_json=False, tipo="DIAGNOSTICO_REINTENTO")
            if texto2 and texto2 != "no_modelo":
                try:
                    resultado = extraer_json(texto2)
                except ValueError:
                    resp = texto_libre_como_respaldo(texto2, especie_contexto, modelo)
                    if resp:
                        print(f"✅ Gemini ({modelo}): usando texto libre")
                        return resp
        if resultado is None:
            continue
        print(f"✅ Gemini respondió con {modelo}")
        return construir_resultado(resultado, especie_contexto, modelo)

    print("⚠️ Ningún modelo de Gemini funcionó")
    return None


# ============================================================
# QWEN (RESPALDO)
# ============================================================

def diagnostico_qwen(img, especie_contexto=None):
    """Se ejecuta solo si Gemini falla."""
    if not QWEN_KEY:
        print("⚠️ QWEN_API_KEY no configurada (respaldo desactivado)")
        return None
    if not QWEN_MODELOS:
        print("⚠️ No hay modelos Qwen configurados")
        return None

    print(f"🔄 Intentando Qwen como respaldo...")
    contexto = f"\nIdentificación botánica probable: {especie_contexto}." if especie_contexto else ""
    prompt = PROMPT_DIAGNOSTICO.format(contexto=contexto)
    img_bytes = imagen_a_jpeg_bytes(img)
    img_b64 = base64.b64encode(img_bytes).decode("utf-8")
    data_uri = f"data:image/jpeg;base64,{img_b64}"

    for modelo in QWEN_MODELOS:
        try:
            print(f"🔄 Llamando a Qwen ({modelo})...")
            r = _post_medido(f"Qwen {modelo} intento 1",
                f"{QWEN_BASE}/chat/completions",
                headers={"Authorization": f"Bearer {QWEN_KEY}", "Content-Type": "application/json"},
                json={
                    "model": modelo,
                    "messages": [{
                        "role": "user",
                        "content": [
                            {"type": "text", "text": prompt},
                            {"type": "image_url", "image_url": {"url": data_uri}},
                        ],
                    }],
                    "temperature": 0.2,
                    "max_tokens": 2048,
                },
                timeout=10,
            )

            print(f"📡 Qwen ({modelo}): Status {r.status_code}")

            if r.status_code == 404:
                print(f"⚠️ Qwen modelo no disponible: {modelo}")
                continue
            if r.status_code in (429, 503):
                print(f"⚠️ Qwen ({modelo}): {r.status_code} — reintentando en 2 s")
                time.sleep(2)
                r = _post_medido(f"Qwen {modelo} reintento",
                    f"{QWEN_BASE}/chat/completions",
                    headers={"Authorization": f"Bearer {QWEN_KEY}", "Content-Type": "application/json"},
                    json={
                        "model": modelo,
                        "messages": [{
                            "role": "user",
                            "content": [
                                {"type": "text", "text": prompt},
                                {"type": "image_url", "image_url": {"url": data_uri}},
                            ],
                        }],
                        "temperature": 0.2,
                        "max_tokens": 2048,
                    },
                    timeout=15,
                )
                print(f"📡 Qwen ({modelo}) retry: Status {r.status_code}")
            
            r.raise_for_status()

            data = r.json()
            contenido = data["choices"][0]["message"]["content"]
            if isinstance(contenido, list):
                texto = "".join(p.get("text", "") for p in contenido).strip()
            else:
                texto = str(contenido).strip()

            print(f"📝 Qwen ({modelo}): Respuesta recibida ({len(texto)} chars)")

            try:
                resultado = extraer_json(texto)
                print(f"✅ Qwen respondió con {modelo}")
                return construir_resultado(resultado, especie_contexto, modelo)
            except ValueError as e:
                print(f"⚠️ Qwen ({modelo}): JSON inválido - {e}. Texto: {texto[:150]!r}")
                resp = texto_libre_como_respaldo(texto, especie_contexto, modelo)
                if resp:
                    print(f"✅ Qwen ({modelo}): usando texto libre")
                    return resp

        except requests.HTTPError as e:
            code = getattr(getattr(e, "response", None), "status_code", None)
            response_text = getattr(getattr(e, "response", None), "text", "")
            print(f"⚠️ Qwen ({modelo}): HTTP {code} - {response_text[:200]}")
            continue
        except Exception as e:
            print(f"⚠️ Qwen ({modelo}): {type(e).__name__}: {e}")
            continue

    print("⚠️ Ningún modelo de Qwen funcionó")
    return None


# ============================================================
# FALLBACK LOCAL DE SALUD
# ============================================================

def analizar_salud_local(img, cultivo=None, perfil=None):
    hsv = np.asarray(img.convert("HSV"), dtype=np.int32)
    H, S, V = hsv[..., 0], hsv[..., 1], hsv[..., 2]
    vegetacion = (S > 40) & (V > 40) & (H >= 12) & (H <= 105)
    total = vegetacion.sum() or 1
    verde = ((H >= 45) & (H <= 105) & vegetacion).sum() / total
    amarillo = ((H >= 30) & (H < 45) & vegetacion).sum() / total
    marron = ((H >= 12) & (H < 30) & vegetacion).sum() / total

    sintomas = []
    recs = []
    score = 100
    if amarillo > 0.45:
        score -= 20
        sintomas.append("Amarilleo visible en parte importante de la planta")
        recs.append("Revisa exceso o falta de riego y considera aporte de nutrientes si procede.")
    if marron > 0.35:
        score -= 20
        sintomas.append("Zonas marrones o secas visibles")
        recs.append("Retira partes muy dañadas y revisa estrés hídrico, sol directo o raíces.")
    if verde < 0.35:
        score -= 10
        sintomas.append("Vigor verde bajo")
        recs.append("Revisa luz, riego y estado general del sustrato.")

    p_bin = correr(SESION_ANOMALIA, img)
    p_enfermo = float(p_bin[0]) if p_bin is not None else None
    if p_enfermo is not None and p_enfermo > 0.85:
        score = min(score, 70)
        sintomas.append(f"El modelo local detecta posible anomalía foliar ({p_enfermo*100:.0f}% prob.)")
        recs.append("Inspecciona de cerca el envés de las hojas y compara evolución en varios días.")

    p_dis = correr(SESION_SALUD, img)
    enfermedad = None
    if p_dis is not None and MAPEO_SALUD and cultivo:
        idx = int(np.argmax(p_dis))
        conf = float(p_dis[idx])
        info = MAPEO_SALUD.get(str(idx))
        if info:
            cultivo_pred = PREFIJO_CULTIVO.get(info["id"].split("___")[0])
            if cultivo_pred == cultivo and not info["id"].endswith("healthy") and conf > 0.70:
                enfermedad = (info, conf)
    if enfermedad:
        info, conf = enfermedad
        score = min(score, max(15, int(100 - conf * 75)))
        sintomas.insert(0, f"Enfermedad compatible: {info.get('nombre_es', info.get('id'))} ({conf*100:.0f}%)")
        recs.insert(0, info.get("consejo", "Consulta tratamiento específico para esta enfermedad."))

    if sintomas and perfil:
        recs.append(perfil["consejo_sintomas"])
    if not sintomas:
        sintomas = ["Sin síntomas claros detectados por el respaldo local"]
        recs = ["Si observas manchas o plagas, haz una foto cercana de la hoja afectada y vuelve a analizar."]

    score = max(5, min(100, int(score)))
    estado = "saludable" if score >= 80 else ("atencion" if score >= 55 else "critico")

    return {
        "puntuacion": score, "estado": estado,
        "sintomas": sintomas, "recomendaciones": recs,
        "diagnostico": "Diagnóstico local limitado. Para mayor precisión se recomienda conexión con IA.",
        "fuente": "local",
        "detalle": {
            "verde": round(float(verde), 3),
            "amarillo": round(float(amarillo), 3),
            "marron": round(float(marron), 3),
        },
        "modelos": {
            "prob_sintomas": round(p_enfermo, 3) if p_enfermo is not None else None,
            "cultivo_detectado": cultivo,
            "enfermedad": (
                {"nombre": enfermedad[0].get("nombre_es"), "confianza": round(enfermedad[1], 3)}
                if enfermedad else None
            ),
        },
    }


def score_desde_estado(estado, confianza=0.7):
    confianza = max(0.0, min(1.0, confianza))
    if estado == "saludable": return 100
    if estado == "atencion": return int(78 - confianza * 25)
    if estado == "critico": return int(50 - confianza * 30)
    return 70


# ============================================================
# VALIDACIÓN DE ENTRADAS
# ============================================================

async def leer_imagen_validada(upload: UploadFile) -> Image.Image:
    """Lee una imagen con límite de tamaño y valida que Pillow pueda decodificarla."""
    contenido = await upload.read(MAX_IMAGE_BYTES + 1)
    if not contenido:
        raise HTTPException(status_code=400, detail="La imagen está vacía.")
    if len(contenido) > MAX_IMAGE_BYTES:
        raise HTTPException(
            status_code=413,
            detail=f"La imagen supera el límite de {MAX_IMAGE_BYTES // (1024 * 1024)} MB."
        )
    try:
        imagen = Image.open(io.BytesIO(contenido))
        imagen = ImageOps.exif_transpose(imagen)
        imagen.load()
        if imagen.mode not in ("RGB", "RGBA"):
            imagen = imagen.convert("RGB")
        return imagen
    except Exception:
        raise HTTPException(status_code=400, detail="No se pudo leer la imagen. Usa JPG, PNG o WEBP.")


# ============================================================
# ENDPOINTS
# ============================================================
import asyncio
from fastapi import File, UploadFile
from fastapi.responses import JSONResponse

def detectar_si_es_planta(img):
    """
    Valida que el sujeto principal sea una planta real.
    Si la respuesta es ambigua o incompleta, no autoriza el diagnóstico.
    """
    if not GEMINI_KEY:
        print("⚠️ Sin GEMINI_API_KEY: no se puede validar la planta")
        return None

    img_b64 = base64.b64encode(
        imagen_a_jpeg_bytes(img, max_px=768)
    ).decode("utf-8")

    prompt = """
Analiza visualmente la imagen antes de permitir un diagnóstico botánico.

Devuelve exclusivamente un JSON válido con estos campos:
{
  "es_planta": false,
  "confianza": 0.0,
  "sujeto_principal": "persona, vehículo, objeto, planta u otro",
  "evidencia_vegetal": "descripción concreta de hojas, tallo,
  flores u otras estructuras vegetales visibles",
  "motivo": "explicación breve"
}

REGLAS OBLIGATORIAS:
1. es_planta solo puede ser true si una planta REAL es claramente
   visible y constituye el sujeto principal de la fotografía.
2. Si el sujeto principal es una persona, un rostro, un animal,
   un coche, un edificio u otro objeto, devuelve false.
3. No confundas ropa, cabello, piel, fondos verdes, dibujos ni
   objetos decorativos con estructuras vegetales.
4. No deduzcas que hay una planta solo porque podría estar fuera
   del encuadre o en el fondo.
5. Si no puedes distinguir estructuras vegetales reales, devuelve
   false.
6. Si la imagen muestra una persona sosteniendo una planta, solo
   devuelve true si la planta es claramente visible y es el sujeto
   principal.
7. No inventes hojas, tallos ni flores que no se vean.
8. La confianza debe reflejar la seguridad de que el sujeto
   principal es realmente una planta.

Responde solo con el JSON.
"""

    for modelo in MODELOS_GEMINI:
        texto = _pedir_texto_gemini(
            modelo, prompt, img_b64, forzar_json=True, tipo="VALIDACION_PLANTA"
        )

        if not texto or texto == "no_modelo":
            continue

        try:
            data = extraer_json(texto)

            es_planta = data.get("es_planta")
            confianza = float(data.get("confianza", 0))
            sujeto = str(
                data.get("sujeto_principal", "")
            ).strip().lower()
            evidencia = str(
                data.get("evidencia_vegetal", "")
            ).strip().lower()

            sujeto_valido = (
                sujeto == "planta"
                or sujeto.startswith("planta ")
            )

            evidencia_valida = (
                bool(evidencia)
                and evidencia not in {
                    "ninguna", "ninguna visible",
                    "no se observa", "no hay"
                }
            )

            aceptada = (
                es_planta is True
                and confianza >= 0.85
                and sujeto_valido
                and evidencia_valida
            )

            print(
                "🔎 Validación estricta:",
                f"aceptada={aceptada},",
                f"confianza={confianza:.2f},",
                f"sujeto={sujeto!r},",
                f"evidencia={evidencia[:120]!r}"
            )

            # Una respuesta JSON válida pero ambigua no autoriza
            # a generar un diagnóstico de salud.
            return aceptada

        except (ValueError, TypeError, AttributeError) as e:
            print(f"⚠️ Respuesta inválida del preclasificador: {e}")

    print("⚠️ No se pudo confirmar visualmente la presencia de una planta")
    return None


@app.post("/analizar")
async def analizar(imagen: UploadFile = File(...)):
    img = await leer_imagen_validada(imagen)
    # Validar contenido antes de invocar el diagnóstico (evita coches -> 'olivo sano').
    loop = asyncio.get_running_loop()
    try:
        es_planta = await asyncio.wait_for(
            loop.run_in_executor(EXECUTOR, detectar_si_es_planta, img),
            timeout=12.0
        )
    except Exception as e:
        print(f"⚠️ No se pudo validar si es planta: {e}")
        es_planta = None

    if es_planta is False:
        raise HTTPException(
            status_code=422,
            detail="No hemos detectado una planta con suficiente seguridad. Haz una foto de una planta real, sus hojas o sus flores e inténtalo de nuevo."
        )
    if es_planta is None:
        # Fallar de forma segura: no emitir diagnósticos cuando no se ha podido validar la imagen.
        raise HTTPException(
            status_code=503,
            detail="Ahora mismo no podemos comprobar si la foto contiene una planta. Inténtalo de nuevo en unos momentos."
        )
    # Contamos solo peticiones con imagen válida, no cargas malformadas.
    _stats_contar("escaneos")
    img_bytes_jpeg = imagen_a_jpeg_bytes(img, max_px=1024)
    loop = asyncio.get_running_loop()

    # -------------------------------------------------------------
    # 1. PLAN A: Consultar directamente a Gemini (hasta 35s para los modelos en cascada)
    # -------------------------------------------------------------
    ia_gemini = None
    inicio_plan_a = time.perf_counter()
    try:
        print("Plan A: Consultando a Gemini...")
        ia_gemini = await asyncio.wait_for(
            loop.run_in_executor(EXECUTOR, diagnostico_gemini, img, None),
            timeout=35.0
        )
    except asyncio.TimeoutError:
        print("⏱️ Gemini superó el tiempo límite (35s). Pasando al Plan B...")
    except Exception as e:
        print(f"⚠️ Error consultando Gemini: {e}. Pasando al Plan B...")
    finally:
        print(f"⏱️ [Plan A Gemini] {time.perf_counter() - inicio_plan_a:.2f} s (tiempo observado por el endpoint)")

    if ia_gemini and not MODO_PRUEBA_QWEN:
        fuente_ia = "gemini"
        ia = ia_gemini
        # Para la especie, lanzamos una identificación rápida si es posible o usamos lo de la IA
        local = identificar_local(img)
        especie_contexto = ia.get("especie")
        cuidados = {
            "grupo": "Planta",
            "riego": ia.get("riego") or "Según necesidad",
            "luz": ia.get("luz") or "Luz indirecta",
            "tipico": "Observar respuesta y ajustar"
        }
        
        estado = normalizar_estado(ia.get("estado"))
        confianza = float(ia.get("confianza", 0.7))
        puntuacion = score_desde_estado(estado, confianza)
        recomendaciones = list(ia.get("tratamiento") or [])
        prevencion = ia.get("prevencion") or []
        if prevencion:
            recomendaciones.append("Prevención: " + " ".join(prevencion))
        if not recomendaciones and estado == "saludable":
            recomendaciones = ["Mantén los cuidados habituales y revisa periódicamente hojas y envés."]

        salud = {
            "puntuacion": puntuacion, "estado": estado,
            "sintomas": ia.get("sintomas") or [],
            "recomendaciones": recomendaciones,
            "diagnostico": ia.get("diagnostico") or "",
            "patogeno": ia.get("patogeno") or "",
            "guia": ia.get("guia") or {},
            "fuente": fuente_ia,
            "confianza": round(confianza, 2),
            "modelo": ia.get("modelo"),
        }
        return {
            "especie": {
                "fuente": fuente_ia,
                "plantnet": [], "local": local,
                "nombre_comun": especie_contexto or "Planta sin identificar",
            },
            "salud": salud,
            "cuidados": cuidados,
            "aviso": "Diagnóstico asistido por IA. Es orientativo; en casos graves consulta a un experto o vivero.",
        }

    # -------------------------------------------------------------
    # 2. PLAN B: Si Gemini falla, usar Pl@ntNet + Qwen / Modelo local
    # -------------------------------------------------------------
    print("Plan B: Identificando especie con Pl@ntNet y local...")
    try:
        task_plantnet = loop.run_in_executor(EXECUTOR, identificar_plantnet, img_bytes_jpeg)
        task_local = loop.run_in_executor(EXECUTOR, identificar_local, img)
        plantnet, local = await asyncio.gather(task_plantnet, task_local, return_exceptions=True)
        plantnet = plantnet if not isinstance(plantnet, Exception) else []
        local = local if not isinstance(local, Exception) else []
    except Exception as e:
        print(f"Error en identificación Plan B: {e}")
        plantnet, local = [], []

    fuente_usada, textos_perfil = elegir_especie(plantnet, local)
    cultivo = detectar_cultivo(plantnet, local)
    perfil = perfil_de(textos_perfil)

    especie_contexto = None
    if plantnet:
        pn0 = plantnet[0]
        especie_contexto = pn0.get("nombre_comun") or pn0.get("nombre_cientifico")
    elif local:
        especie_contexto = local[0].get("clase")

    cuidados = None
    if perfil:
        cuidados = {"grupo": perfil["grupo"], "riego": perfil["riego"],
                    "luz": perfil["luz"], "tipico": perfil["tipico"]}

    # Intentar Qwen como respaldo de la IA si Gemini falló
    ia = None
    inicio_qwen = time.perf_counter()
    try:
        ia = await asyncio.wait_for(
            loop.run_in_executor(EXECUTOR, diagnostico_qwen, img, especie_contexto),
            timeout=30.0
        )
    except asyncio.TimeoutError:
        print("⏱️ Qwen superó el límite de 30s; se continúa con el Plan C local.")
    except Exception as e:
        print(f"Qwen de respaldo falló o no está configurado: {e}")
    finally:
        print(f"⏱️ [Plan Qwen] {time.perf_counter() - inicio_qwen:.2f} s (tiempo observado por el endpoint)")

    if ia:
        fuente_ia = "qwen"
        if not cuidados and ia.get("luz") and ia.get("riego"):
            cuidados = {
                "grupo": "Planta",
                "riego": ia.get("riego"),
                "luz": ia.get("luz"),
                "tipico": "Observar respuesta y ajustar"
            }

        estado = normalizar_estado(ia.get("estado"))
        confianza = float(ia.get("confianza", 0.7))
        puntuacion = score_desde_estado(estado, confianza)
        recomendaciones = list(ia.get("tratamiento") or [])
        prevencion = ia.get("prevencion") or []
        if prevencion:
            recomendaciones.append("Prevención: " + " ".join(prevencion))
        if not recomendaciones and estado == "saludable":
            recomendaciones = ["Mantén los cuidados habituales y revisa periódicamente hojas y envés."]

        salud = {
            "puntuacion": puntuacion, "estado": estado,
            "sintomas": ia.get("sintomas") or [],
            "recomendaciones": recomendaciones,
            "diagnostico": ia.get("diagnostico") or "",
            "patogeno": ia.get("patogeno") or "",
            "guia": ia.get("guia") or {},
            "fuente": fuente_ia,
            "confianza": round(confianza, 2),
            "modelo": ia.get("modelo"),
        }
        return {
            "especie": {
                "fuente": fuente_ia,
                "plantnet": plantnet, "local": local,
                "nombre_comun": especie_contexto or "Planta sin identificar",
            },
            "salud": salud,
            "cuidados": cuidados,
            "aviso": "Diagnóstico asistido por IA (Qwen). Es orientativo.",
        }

    # -------------------------------------------------------------
    # 3. PLAN C: Fallback local completo de emergencia
    # -------------------------------------------------------------
    print("Plan C: Usando modelo local de emergencia...")
    salud = analizar_salud_local(img, cultivo=cultivo, perfil=perfil)
    return {
        "especie": {"fuente": fuente_usada, "plantnet": plantnet, "local": local},
        "salud": salud,
        "cuidados": cuidados,
        "aviso": "Análisis local orientativo. Las APIs externas no respondieron.",
    }

# ============================================================
# INFORME DETALLADO (PDF) — 0,50 € / incluido en Pro
# ============================================================

import uuid
import datetime

INFORMES = {}  # token -> PDF en memoria

PROMPT_INFORME = """Eres un botánico experto. Redacta un informe COMPLETO en español sobre la planta de la imagen.
Devuelve SOLO JSON válido:
{{
 "especie": "nombre común (nombre científico)",
 "descripcion": "2-3 frases describiendo la planta",
 "luz": "necesidades de luz detalladas",
 "riego": "pauta completa: frecuencia verano/invierno, cantidad y señales de exceso/falta",
 "sustrato": "tipo de sustrato y drenaje",
 "abono": "pauta de fertilización",
 "poda": "cuándo y cómo podar",
 "temperatura": "rango ideal y resistencia a heladas",
 "plagas": ["plaga: síntoma y tratamiento"],
 "enfermedades": ["enfermedad: síntoma y tratamiento"],
 "calendario": ["Primavera: acciones", "Verano: acciones", "Otoño: acciones", "Invierno: acciones"],
 "consejo_experto": "consejo final personalizado según lo que veas en la imagen"
}}
Máximo 2 frases por campo, 3 plagas, 3 enfermedades. Sin markdown."""


def generar_informe_pdf(d):
    from fpdf import FPDF
    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=18)
    pdf.add_page()
    pdf.set_font("Helvetica", "B", 20)
    pdf.set_text_color(18, 59, 44)
    pdf.cell(0, 12, "FloraScan - Informe detallado", ln=True, align="C")
    pdf.set_font("Helvetica", "", 10)
    pdf.set_text_color(110, 118, 110)
    pdf.cell(0, 8, datetime.date.today().strftime("%d/%m/%Y"), ln=True, align="C")
    pdf.ln(4)

    def seccion(t):
        pdf.set_font("Helvetica", "B", 13)
        pdf.set_text_color(30, 158, 99)
        pdf.ln(3)
        pdf.cell(0, 9, t, ln=True)
        pdf.set_font("Helvetica", "", 11)
        pdf.set_text_color(40, 48, 40)

    def parr(t):
        pdf.multi_cell(0, 6, t or "-")
        pdf.ln(1)

    pdf.set_font("Helvetica", "B", 15)
    pdf.set_text_color(18, 59, 44)
    pdf.multi_cell(0, 9, d.get("especie", "Planta"), align="C")
    pdf.ln(2)
    seccion("Descripcion"); parr(d.get("descripcion"))
    seccion("Luz"); parr(d.get("luz"))
    seccion("Riego"); parr(d.get("riego"))
    seccion("Sustrato"); parr(d.get("sustrato"))
    seccion("Abono"); parr(d.get("abono"))
    seccion("Poda"); parr(d.get("poda"))
    seccion("Temperatura"); parr(d.get("temperatura"))
    seccion("Plagas frecuentes")
    for x in d.get("plagas", []): parr("- " + x)
    seccion("Enfermedades frecuentes")
    for x in d.get("enfermedades", []): parr("- " + x)
    seccion("Calendario anual")
    for x in d.get("calendario", []): parr("- " + x)
    seccion("Consejo del experto"); parr(d.get("consejo_experto"))
    pdf.ln(4)
    pdf.set_font("Helvetica", "I", 9)
    pdf.set_text_color(140, 148, 140)
    pdf.multi_cell(0, 5, "Informe orientativo generado por IA. No sustituye el diagnostico de un profesional.")
    return pdf.output()


def informe_detallado_gemini(img):
    if not GEMINI_KEY:
        return None
    img_b64 = base64.b64encode(imagen_a_jpeg_bytes(img, max_px=1024)).decode()
    for modelo in MODELOS_GEMINI:
        texto = _pedir_texto_gemini(modelo, PROMPT_INFORME, img_b64, forzar_json=True, tipo="INFORME_DETALLADO")
        if texto in (None, "no_modelo"):
            continue
        try:
            return extraer_json(texto)
        except ValueError:
            continue
    return None


def informe_detallado_qwen(img):
    if not QWEN_KEY:
        return None
    img_b64 = base64.b64encode(imagen_a_jpeg_bytes(img, max_px=1024)).decode()
    for modelo in QWEN_MODELOS:
        try:
            r = _post_medido(f"Qwen informe {modelo}",
                f"{QWEN_BASE}/chat/completions",
                headers={"Authorization": f"Bearer {QWEN_KEY}", "Content-Type": "application/json"},
                json={"model": modelo, "messages": [{"role": "user", "content": [
                    {"type": "text", "text": PROMPT_INFORME},
                    {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{img_b64}"}}]}],
                    "temperature": 0.2, "max_tokens": 3000},
                timeout=90,
            )
            r.raise_for_status()
            contenido = r.json()["choices"][0]["message"]["content"]
            if isinstance(contenido, list):
                contenido = "".join(p.get("text", "") for p in contenido)
            return extraer_json(contenido)
        except Exception:
            continue
    return None


@app.post("/informe")
async def informe(imagen: UploadFile = File(...)):
    img = await leer_imagen_validada(imagen)
    datos = informe_detallado_gemini(img) or informe_detallado_qwen(img)
    if not datos:
        raise HTTPException(503, "La IA no está disponible ahora mismo. Inténtalo en unos minutos.")
    token = uuid.uuid4().hex
    INFORMES[token] = {"pdf": bytes(generar_informe_pdf(datos)), "ts": time.time()}
    ahora = time.time()
    for k in [k for k, v in INFORMES.items() if ahora - v["ts"] > 3600]:
        del INFORMES[k]
    _stats_contar("informes")
    return {"token": token, "url": f"/informe_pdf/{token}"}


@app.get("/informe_pdf/{token}")
def informe_pdf(token: str):
    from fastapi.responses import Response
    item = INFORMES.get(token)
    if not item:
        raise HTTPException(404, "El informe ha caducado. Vuelve a generarlo.")
    return Response(content=item["pdf"], media_type="application/pdf",
                    headers={"Content-Disposition": 'attachment; filename="informe_florascan.pdf"'})

# ============================================================
# CONTADOR DE USO Y COSTES
# ============================================================
import json as _json
STATS_FILE = BASE / "stats.json"
_STATS_LOCK = Lock()

def _stats_leer():
    try: return _json.loads(STATS_FILE.read_text(encoding="utf-8"))
    except Exception: return {"escaneos":0,"informes":0,"por_dia":{}}

def _stats_contar(tipo):
    # Protege incrementos simultáneos dentro de un mismo proceso.
    with _STATS_LOCK:
        s = _stats_leer()
        s[tipo] = s.get(tipo, 0) + 1
        dia = datetime.date.today().isoformat()
        por_dia = s.setdefault("por_dia", {})
        por_dia.setdefault(dia, {"escaneos": 0, "informes": 0})
        por_dia[dia][tipo] = por_dia[dia].get(tipo, 0) + 1
        temporal = STATS_FILE.with_suffix(".tmp")
        temporal.write_text(_json.dumps(s, ensure_ascii=False), encoding="utf-8")
        temporal.replace(STATS_FILE)

@app.get("/stats")
def stats(x_stats_token: str = Header(default="", alias="X-Stats-Token")):
    # Este endpoint revela métricas internas. Debe configurarse STATS_TOKEN.
    if not STATS_TOKEN:
        raise HTTPException(status_code=404, detail="Endpoint no disponible.")
    if x_stats_token != STATS_TOKEN:
        raise HTTPException(status_code=403, detail="No autorizado.")
    s = _stats_leer()
    coste = s.get("escaneos", 0) * 0.002 + s.get("informes", 0) * 0.004
    return {
        **s,
        "coste_estimado_eur": round(coste, 4),
        "nota": "Estimación orientativa fija; no equivale a facturación real de proveedores."
    }


@app.get("/app")
def interfaz():
    return FileResponse(BASE / "app.html")

@app.get("/styles.css")
def estilos():
    return FileResponse(BASE / "styles.css", media_type="text/css")

@app.get("/logo.png")
def logo():
    path = BASE / "logo.png"
    if not path.is_file():
        raise HTTPException(status_code=404, detail="Logo no incluido en esta distribución.")
    return FileResponse(path, media_type="image/png")

@app.get("/fondo-paywall.png")
def fondo_paywall():
    path = BASE / "fondo-paywall.png"
    if not path.is_file():
        raise HTTPException(status_code=404, detail="Fondo de pago no incluido en esta distribución.")
    return FileResponse(path, media_type="image/png")

@app.get("/app.js")
def script():
    return FileResponse(BASE / "app.js", media_type="text/javascript")


@app.get("/")
def raiz():
    return {
        "estado": "FloraScan API activa 🌿",
        "version": "4.10",
        "app": "/app", "docs": "/docs",
        "gemini_configurado": bool(GEMINI_KEY),
        "qwen_configurado": bool(QWEN_KEY),
        "plantnet_configurado": bool(PLANTNET_KEY),
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)